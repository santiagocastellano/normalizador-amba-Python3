=======
Credits
=======

Lead Developers
---------------

* `Hernán Ogasawara`_ <hogasawara@buenosaires.gob.ar>
* `Pablo Cecconi`_ <pcecconi@buenosaires.gob.ar>


.. _`Hernán Ogasawara`: https://github.com/hogasa
.. _`Pablo Cecconi`: https://github.com/pcecconi
