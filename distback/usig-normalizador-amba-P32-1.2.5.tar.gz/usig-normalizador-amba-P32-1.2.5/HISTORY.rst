.. :changelog:

History
-------
1.2.5 (2018-12-15)
------------------
* Migracion a python 3.6
* Modificacion de manejo de excepciones
* Modificacion de llamada a servicio externo callejero


1.2.4 (2016-12-27)
------------------
* BUGFIX: problema de encoding en el método __str__ de la clase ErrorTextoSinDireccion.
* Fix a la url del callejero CABA


1.2.3 (2016-10-04)
------------------
* Si no logra normalizar el texto ingresado, prueba quitandole avenida y/o pasaje.


1.2.2 (2016-08-17)
------------------
* BUGFIX en el buscador de direcciones.


1.2.1 (2016-07-15)
------------------
* BUGFIX: Códigos de calles duplicados o inexistentes.
* PEP 8 compatible.


1.2.0 (2016-07-01)
------------------
* Primera versión publicable PyPi.


1.1.0 (2016-06-23)
------------------
* Incorporación del callejero de CABA.
* Buscador de direcciones.


1.0.0 (2015-09-07)
------------------
* Primera versión del Normalizador de Direcciones AMBA.
